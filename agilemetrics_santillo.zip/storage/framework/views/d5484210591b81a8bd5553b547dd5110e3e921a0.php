

<?php $__env->startSection('content'); ?>
  <div class="container main-admin-post-show">
    <div class="row justify-content-center">

        <div class="col-md-6">

          <h1 class="text-capitalize"><?php echo e($post->title); ?></h1>
          

          <?php if($post->cover): ?>
            <img class="cover" src="<?php echo e(asset($post->cover)); ?>" alt="<?php echo e($post->title); ?>">
          <?php endif; ?>

          <p><?php echo e($post->content); ?></p>

          

          <div class="row justify-content-center">
            <a href="<?php echo e(route('admin.posts.index')); ?>">
              <button class="btn btn-primary mr-5" type="button" name="button">
                Torna all'indice
              </button>

              <a class="mr-5" href="<?php echo e(route('admin.posts.edit', ['post' => $post->id])); ?>">
                <button class="btn btn-primary" type="button" name="button">Modifica</button>
              </a>

              <form class="" action="<?php echo e(route('admin.posts.destroy', ['post' => $post->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-primary" name="button">Cancella</button>
              </form>


            </a>
          </div>

        </div>


    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adicr\Documents\Boolean\agilemetrics_santillo\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>