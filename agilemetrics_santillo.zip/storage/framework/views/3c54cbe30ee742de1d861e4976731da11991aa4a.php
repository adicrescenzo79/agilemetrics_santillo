

<?php $__env->startSection('content'); ?>
  <div class="container main-admin-post-index">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <a href="<?php echo e(route('admin.posts.create')); ?>">
          <button class="btn btn-primary" type="button" name="button">
            Scrivi un nuovo post
          </button>

        </a>
      </div>
    </div>
    <div class="row justify-content-center">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-3">
          <div class="card mt-3">
            <div class="card-header">

              <a class="mr-5 text-capitalize" href="<?php echo e(route('admin.posts.show', ['post' => $post->id])); ?>">
                <?php echo e($post->title); ?>

              </a>
            </div>

            <div class="card-body">
              <?php echo e($post->content); ?>

              <div class="row justify-content-center flex-wrap mt-5">
                <a class="mr-5" href="<?php echo e(route('admin.posts.edit', ['post' => $post->id])); ?>">
                  <button class="btn btn-primary" type="button" name="button">Modifica</button>
                </a>
                <form class="" action="<?php echo e(route('admin.posts.destroy', ['post' => $post->id])); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-primary" name="button">Cancella</button>
                </form>
              </div>
            </div>
          </div>
        </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adicr\Documents\Boolean\agilemetrics_santillo\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>