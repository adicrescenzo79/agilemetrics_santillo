

<?php $__env->startSection('content'); ?>
  <div id="main-welcome">
    <div class="container">
      <div class="row justify-content-center">
        <h1>BENVENUTI IN AGILE METRICS</h1>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-script'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.10.6/dayjs.min.js" integrity="sha512-bwD3VD/j6ypSSnyjuaURidZksoVx3L1RPvTkleC48SbHCZsemT3VKMD39KknPnH728LLXVMTisESIBOAb5/W0Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="<?php echo e(asset('js/welcome.js')); ?>" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adicr\Documents\Boolean\agilemetrics_santillo\resources\views/welcome.blade.php ENDPATH**/ ?>