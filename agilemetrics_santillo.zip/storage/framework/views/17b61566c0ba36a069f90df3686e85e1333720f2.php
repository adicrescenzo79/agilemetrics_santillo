

<?php $__env->startSection('content'); ?>
  <div id="main_security">
    <div class="container mt-2">
      <div class="row justify-content-center">
        <div class="col-md-12 flex justify-content-center align-items-center flex-column">
          <img src="<?php echo e(asset('img/poliziotto.jpg')); ?>" alt="">
          <div class="msg flex-center flex-column mt-4">
            <h1>ALT! <br> Non puoi accedere a questo elemento!</h1>
            <a class="btn my-btn mt-5" href="<?php echo e(route('welcome')); ?>">Torna alla HomePage</a>
          </div>

        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-script'); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adicr\Documents\Boolean\agilemetrics_santillo\resources\views/security.blade.php ENDPATH**/ ?>