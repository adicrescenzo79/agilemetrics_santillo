<footer>
  <h1>footer</h1>
</footer>
<?php /**PATH C:\Users\adicr\Documents\Boolean\agilemetrics_santillo\resources\views/partials/footer.blade.php ENDPATH**/ ?>