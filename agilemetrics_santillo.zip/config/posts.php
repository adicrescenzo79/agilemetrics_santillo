<?php

return $posts = [
  [
    "user_id" => 1,
    "title" => "prova tutti 1",
    "content" => "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    "cover" => "https://i.pinimg.com/originals/e3/2c/b7/e32cb785452bbd096e1c5eb448ada283.jpg",//link
    "visibility" => 1,// 0-1
    "slug" => "prova-tutti-1",
  ],
  [
    "user_id" => 1,
    "title" => "prova tutti 2",
    "content" => "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    "cover" => "https://i.pinimg.com/originals/e3/2c/b7/e32cb785452bbd096e1c5eb448ada283.jpg",//link
    "visibility" => 1,// 0-1
    "slug" => "prova-tutti-2",

  ],
  [
    "user_id" => 1,
    "title" => "prova pochi 1",
    "content" => "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    "cover" => "https://i.pinimg.com/originals/e3/2c/b7/e32cb785452bbd096e1c5eb448ada283.jpg",//link
    "visibility" => 0,// 0-1
    "slug" => "prova-pochi-1",

  ],
  [
    "user_id" => 1,
    "title" => "prova pochi 2",
    "content" => "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    "cover" => "https://i.pinimg.com/originals/e3/2c/b7/e32cb785452bbd096e1c5eb448ada283.jpg",//link
    "visibility" => 0,// 0-1
    "slug" => "prova-pochi-2",

  ],

];
