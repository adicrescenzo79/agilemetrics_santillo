<?php

return $users = [
  [
    "name" => "alessandro di crescenzo",
    "password" => "password",
    "email" => "limone79@gmail.com"
  ],
  [
    "name" => "gino pino",
    "password" => "password",
    "email" => "limone79@hotmail.it"
  ],
  [
    "name" => "luca santillo",
    "password" => "password",
    "email" => "luca.santillo@gmail.com"
  ],



]

?>
